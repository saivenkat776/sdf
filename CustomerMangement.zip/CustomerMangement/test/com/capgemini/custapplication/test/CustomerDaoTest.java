package com.capgemini.custapplication.test;

import static org.junit.Assert.*;

//import java.sql.Date;
//import java.time.LocalDate;

//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.dao.CustomerDaoImpl;
import com.capgemini.custapplication.exception.CustomerException;
//import com.capgemini.custapplication.service.CustServiceImpl;
//import com.capgemini.custapplication.service.ICustService;

public class CustomerDaoTest {

	static CustomerDaoImpl dao;
	static CustomerBean cust;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new CustomerDaoImpl();
		cust = new CustomerBean();
	}

	@Test
	public void testAddCustDetails() throws CustomerException {

		assertNotNull(dao.addCustomerDetails(cust));

	}


	@Ignore
	@Test
	public void testAddCustDetails1() throws CustomerException {
		// increment the number next time you test for positive test case
		assertEquals(40, dao.addCustomerDetails(cust));
	}

	

	@Test
	public void testAddCustDetails2() throws CustomerException {
         
		cust.setFullname("raviteja");
		cust.setPhonenumber("9676355060");
		cust.setCity("hyderabda");
		//cust.setAddress("hyderabad");
		cust.setCountry("india");
		
		assertNotNull("63", dao.addCustomerDetails(cust));
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addCustomerDetails(cust)) > 20);

	}

	
	@Test
	public void testViewAll() throws CustomerException {
		assertNotNull(dao.retriveAllDetails());
	}



	/*@Test
	public void testById() throws CustException {
		assertNotNull(dao.updateCustDetails("65","shdah@h.com","ravi"));
	}
*/

}
