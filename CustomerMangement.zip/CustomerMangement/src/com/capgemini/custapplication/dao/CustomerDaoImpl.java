package com.capgemini.custapplication.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.exception.CustomerException;
import com.capgemini.custapplication.util.*;

public class CustomerDaoImpl implements ICustomerDAO
{
	
	Logger logger=Logger.getRootLogger();
	public CustomerDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	PreparedStatement preparedStatement=null;		
	ResultSet resultSet = null;
	
	//------------------------ 1. Customer Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addCustDetails(CustBean cu)
			 - Input Parameters	:	CustomerBean cu
			 - Return Type		:	String
			 - Throws			:  	CustException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	16/06/2019
			 - Description		:	Adding Customer Details
			 ********************************************************************************************************/
	
	public String addCustomerDetails(CustomerBean cu) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String customerId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,cu.getEmail());			
			preparedStatement.setString(2,cu.getFullname());
			preparedStatement.setString(3,cu.getPassword());
			preparedStatement.setString(4,cu.getConfirmpassword());
			preparedStatement.setString(5,cu.getPhonenumber());
			preparedStatement.setString(6,cu.getAddress());
			preparedStatement.setString(7,cu.getCity());
			preparedStatement.setString(8,cu.getZipcode());
			preparedStatement.setString(9,cu.getCountry());
						
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				customerId=resultSet.getString(1);
				
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustomerException("Inserting customer details failed ");

			}
			else
			{
				logger.info("customer details added successfully:");
				return customerId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		}
	
	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	UpdateCustDetails(String user,String email,String name)
	 - Input Parameters	:	Custid,email,name
	 - Return Type		:	String
	 - Throws			:  	CustException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	16/06/2019
	 - Description		:	Updating Customer Details
	 ********************************************************************************************************/
	
	
	/*public boolean updateCustomerDetails(String user,String email,String name) throws CustomerException 
	{
	 
	 
	Connection connection = DBConnection.getInstance().getConnection();	
	 
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int queryResult=0;
		//CustBean bean;
	    try
	    {
	 
	    	int idd= Integer.parseInt(user);
	    	preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUST_DETAILS_QUERY);
	    	preparedStatement.setInt(3,idd);
	    	preparedStatement.setString(2,name );
	    	preparedStatement.setString(1,email );
	    	queryResult=preparedStatement.executeUpdate();
	 
	    	if(queryResult==0)
			{
				logger.error("failed in updating ");
				throw new CustomerException("updation user details failed :user id doesn't exists");
	 
			}
			else
			{
				//System.out.println("user details updated successfully:");
				logger.info("user details updated successfully:");
				return true;
			}
	 
	    }
	    catch (SQLException sqlException) 
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Error in closing db connection");
	 
		}
	    finally 
	    {
	    	try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");
	 
			}
	 
	 
	    }
		}*/
	//------------------------ 1. Customer Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	retriveAllDetails()
		 - Input Parameters	:	
		 - Return Type		:	List
		 - Throws			:  	CustException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	16/06/2019
		 - Description		:	Listing Customer Details
		 ********************************************************************************************************/
	
	public List<CustomerBean> retriveAllDetails() throws CustomerException
	{
		
		Connection con=DBConnection.getInstance().getConnection();
		int customerCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CustomerBean> custList=new ArrayList<CustomerBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CustomerBean bean=new CustomerBean();
				bean.setCustomerid(resultset.getInt(1));
				bean.setEmail(resultset.getString(2));
				bean.setFullname(resultset.getString(3));
				bean.setCity(resultset.getString(4));
				bean.setCountry(resultset.getString(5));
				bean.setRegestrationdate(resultset.getDate(6));
				
				//CUSTID,EMAIL,FULLNAME,CITY,COUNTRY,REGESTRATIONDATE
				
				
				custList.add(bean);
				
				customerCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		if( customerCount == 0)
			return null;
		else
			return custList;
	}
	
	//------------------------ 1. Customer Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deleteAllDetails(String cust1)
			 - Input Parameters	:	String cust1
			 - Return Type		:	void
			 - Throws			:  	CustException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	16/06/2019
			 - Description		:	Delete Customer Details
			 * @return 
			 ********************************************************************************************************/
	
	
	public  CustomerBean deleteCustomerDetails(String cust1) throws CustomerException
	{
		 
		Connection connection = DBConnection.getInstance().getConnection();	
		 
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			int queryResult1=0;
			CustomerBean bean = null;
		 
		 
		    try
		    {
		 
		    	int i= Integer.parseInt(cust1);
		    	preparedStatement=connection.prepareStatement(QueryMapper.DELETE_CUST_DETAILS_QUERY);
		    	preparedStatement.setInt(1,i);
		    	queryResult1=preparedStatement.executeUpdate();
		 
		    	if(queryResult1==0)
				{
					logger.error("failed in updating ");
					throw new CustomerException("CUSTOMER ID NOT FOUND");
		 
				}
				else
				{
				
					logger.info("CUSTOMER details updated successfully:");
		
				}
		 
		    }
		    catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");
		 
			}
		    finally 
		    {
		    	try 
				{
					//resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					logger.error(sqlException.getMessage());
					throw new CustomerException("Error in closing db connection");
		 
				}
		 
		 
		    }
		    return bean;
			}
	
	
	
	
	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	LoginAllAdmin(String email)
	 - Input Parameters	:	String 
	 - Return Type		:	String email
	 - Throws			:  	CustException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	16/06/2019
	 - Description		:	LoginAdmin
	 ********************************************************************************************************/
	public String loginadmin(String email) throws CustomerException
	{
		Connection connection=DBConnection.getInstance().getConnection();
		ResultSet resultSet;
		//CustBean Bean=new CustBean();
		String pwd=null;
		int t=0;
		try
		{
			PreparedStatement PreparedStatement= connection.prepareStatement(QueryMapper.LOGIN_QUERY);
			PreparedStatement.setString(1, email);
			resultSet=PreparedStatement.executeQuery();
			while (resultSet.next()) 
			{
 
				//Bean=new LoginBean();
				 pwd=resultSet.getString(1);

				t++; 
			}
 
 
		}
		catch(Exception exception)
		{
			logger.error(exception.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		if(t==1) 
		{
		return pwd;
		}
		else
		{
			throw new CustomerException("invalid details");
		}
		
	}
		
	///update11
	public String updateCustomerDetails(CustomerBean customer) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;

		String Id="success";
		String query="";
		int queryResult=0;



		try
		{			

			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_QUERY);


			preparedStatement.setString(1,customer.getEmail());
			preparedStatement.setString(2,customer.getFullname());	
			preparedStatement.setString(3,customer.getPassword());
			preparedStatement.setString(4,customer.getConfirmpassword());
			preparedStatement.setString(5,customer.getPhonenumber());
			preparedStatement.setString(6,customer.getAddress());
			preparedStatement.setString(7,customer.getCity());
			preparedStatement.setString(8,customer.getZipcode());
			preparedStatement.setString(9,customer.getCountry());
			preparedStatement.setInt(10,customer.getCustomerid());


			queryResult=preparedStatement.executeUpdate();




			if(queryResult==0)
			{
				logger.error("Updation failed ");
				throw new CustomerException("Updating Customer details failed ");

			}
			else
			{
				logger.info("Customer details Updated successfully:");
				return Id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}


	}



//	validate Id Details

		public boolean validateId(String customerId) throws CustomerException {

			Connection connection=DBConnection.getInstance().getConnection();
			boolean idStatus=false;

			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			CustomerBean bean=null;

			try
			{
				preparedStatement=connection.prepareStatement(QueryMapper.VALIDATE_ID);
				preparedStatement.setString(1,customerId);
				//resultset=preparedStatement.executeUpdate();
				int i=preparedStatement.executeUpdate();

				if(i==1)
				{
					idStatus= true;
				}

			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new CustomerException(e.getMessage());
			}

			return idStatus;
		}
}

