package com.capgemini.custapplication.dao;

import java.util.List;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.exception.CustomerException;

public interface ICustomerDAO
{
  
	public String addCustomerDetails(CustomerBean cu) throws CustomerException;
	public List<CustomerBean> retriveAllDetails() throws CustomerException;
	public CustomerBean deleteCustomerDetails(String cust1) throws CustomerException;
	public String loginadmin(String email) throws CustomerException;
	public String updateCustomerDetails(CustomerBean customer) throws CustomerException;
	public boolean validateId(String customerId) throws CustomerException;
}
