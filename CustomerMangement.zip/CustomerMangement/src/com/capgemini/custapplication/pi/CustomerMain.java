package com.capgemini.custapplication.pi;


import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.exception.CustomerException;
import com.capgemini.custapplication.service.CustomerServiceImpl;
import com.capgemini.custapplication.service.ICustomerService;

public class CustomerMain {

	static Scanner scanner = new Scanner(System.in);
	static ICustomerService customerService = null;
	static CustomerServiceImpl customerServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws CustomerException
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		CustomerBean customerBean = null;

		String customerid = null;
		int option = 0;
		boolean b=false;
		try
		{
			
		 System.out.println("--------------WELCOME------------------");
		 System.out.println("enter the email :");
		 String loginemail = scanner.next();
		 System.out.println("enter the password :");
		 String pwd = scanner.next();
		 customerService =new CustomerServiceImpl();
		 String realpwd= customerService.loginadmin(loginemail);
         
		 if (realpwd.equals(pwd))
		 {
			 System.out.println("----------------------------------------");
			 System.out.println("SUCCESSFULLY LOGIN INTO CUSTOMER MANAGEMENT");
			 
		do{
			// show menu
			//System.out.println();
			System.out.println("______________________________");
			System.out.println("CUSTOMER MANAGEMENT ");
			System.out.println("_______________________________");
			System.out.println("1.INSERT CUSTOMER DETAILS ");
			System.out.println("2.UPDATE CUSTOMER");
			System.out.println("3.LISTING CUSTOMERS");
			System.out.println("4.DELETE ");
			System.out.println("5.EXIT");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = scanner.nextInt();

				switch (option) {

				case 1:

					while (customerBean == null) {
						customerBean = populateCustomerBean();
					}

					try {
						customerService = new CustomerServiceImpl();
						customerid = customerService.addCustomerDetails(customerBean);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer  ID Is: " + customerid);

					}
					catch (CustomerException customerException) {
						logger.error("exception occured", customerException);
						System.err.println("ERROR : "+ customerException.getMessage());
					}
					finally {
						customerid = null;
						customerService = null;
						customerBean = null;
					}

					break;

				case 2:
                   
					boolean idStatus=false;
					 String valid;
					System.out.println("Enter Customer ID");
					customerid =scanner.next();
                    try {
   					idStatus = customerService.validateId(customerid);
                    }
                    catch(CustomerException e)
                      {
	                 System.out.println(e.getMessage());
                    }
					while(idStatus==false) {
						System.out.println("Entered CustomerID is not found");
						break;
					}


					while(idStatus==true) {

				while (customerBean == null) {
					customerBean = populateCustomerBean();
				}

				try 
				{
					customerService = new CustomerServiceImpl();
					customerBean.setCustomerid(Integer.parseInt(customerid));
					valid = customerService.updateCustomerDetails(customerBean);


					if(valid.equals("success"))
					{
						System.out.println("Customer Details Updated Successfully");
					}
					else
					{
						System.err.println("Failed to Update Customer Details");
					}



				} catch (CustomerException customerException) {
					logger.error("exception occured", customerException);
					System.err.println("ERROR : "+ customerException.getMessage());
				} finally {
					customerid = null;
					customerService = null;
					customerBean = null;
				}
				idStatus=false;
					}

				break;
					
				
				case 3:

					customerService = new CustomerServiceImpl();
					try {
						List<CustomerBean> custList = new ArrayList<CustomerBean>();
						custList = customerService.retriveAll();

						if (custList != null)
						{
							Iterator<CustomerBean> i = custList.iterator();
							if(i.hasNext())
							{
								
							System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
							System.out.printf("%10s %30s %20s %20s %20s %20s","CUSTID","EMAIL","FULLNAME","CITY","COUNTRTY","REGESTRATION-DATE");
							System.out.println();
							System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");
							for(CustomerBean custbean: custList)
							//while (i.hasNext())
							{
								System.out.format("%10s %30s %20s %20s %20s %20s",custbean.getCustomerid(),custbean.getEmail(),custbean.getFullname(),custbean.getCity(),custbean.getCountry(),custbean.getRegestrationdate());
								System.out.println();
							}
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------");
							}
						}
							
							
							else {
							System.out.println("NO DETAILS FOUND");
						}

					}

					catch (CustomerException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
				case 4:
                       try {
					customerService = new CustomerServiceImpl();
					System.out.println("ENTER CUSTOMER ID TO DELETE");
					int idd1=scanner.nextInt();
					customerService.deleteCustomerDetails(idd1);
					System.out.println("deleted success");
                       }
                       catch(CustomerException e)
                       {
                    	System.out.println(e.getMessage());   
                       }
					
					break;
					
				case 5:

					System.out.print("Exit Customer Management");
					System.exit(0);
					break;
				default:
					System.err.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
          System.out.println("do you want to continue or not:y/n");
          String s=scan();
          if(s.equals("y")|| s.equals("Y"))
          {
        	  b=true;
          }
          else if(s.equals("n")||(s.equals("N")))
          {
        	  System.out.println("thank you");
        	  b=false;
          }
		}while(b);// end of do-while
	}// end of try
		 else//IF
		 {
			 System.err.println("INVALID EMAIL AND PASSWORD");
		 }
		}//TRY
		
		catch(CustomerException e)
		{
			
			System.err.println(e.getMessage());
		}
		
		 
	}	
	
	
	private  static CustomerBean populateCustomerBean() {

		// Reading and setting the values for the donorBean
		
		CustomerBean customerBean = new CustomerBean();
		CustomerServiceImpl  custservice = new CustomerServiceImpl();
        boolean result;
        //CustomerException CustomerException=null;
		System.out.println("\n Enter Details");
        
		System.out.println("Enter customer email: ");
		String str= scan();
		while(true)
		{
		result=custservice.isValidEmail(str);
		if(result)
		{
			customerBean.setEmail(str);
			break;
		}
		else
		{
			System.err.println("enter valid email format(of @ and .)");
			str= scan();
		}
			
		}
		
		
		System.out.println("Enter customer name: ");
		//Scanner sc1= new Scanner(System.in);
		String str1=scan();
		while(true)
		{
		result=custservice.isValidFullName(str1);
		if(result)
		{
			customerBean.setFullname(str1);
			break;
		}
		else
		{
			System.err.println("enter valid customer name format(alphabets) ");
			str1= scan();
		}
			
		}
		
		System.out.println("Enter customer password: ");
		String str4=scan();
		while(true)
		{
		result=custservice.isValidPassword(str4);
		if(result)
		{
			customerBean.setPassword(str4);
			break;
		}
		else
		{
			System.err.println("Password should be greater than 6");
			str4= scan();
		}
			
		}	
   
		System.out.println("Enter customer confirm password:");
		String str5=scan();
		while(true)
		{
		result=custservice.isValidConfirmPassword(str5,str4);
		if(result)
		{
			customerBean.setConfirmpassword(str5);
			break;
		}
		else
		{
			System.err.println("enter correct passsword ");
			str5= scan();
		}
			
		}	
		System.out.println("Enter phone number:");
		String str2=scan();
		while(true)
		{
		result=custservice.isValidPhoneNumber(str2);
		if(result)
		{
			customerBean.setPhonenumber(str2);
			break;
		}
		else
		{
			System.err.println("enter [10] digit customer number format ");
			str2= scan();
		}
			
		}		
		
		System.out.println("Enter address:");
		customerBean.setAddress(scan());
 		
		System.out.println("Enter city:");
		customerBean.setCity(scan());

		
		System.out.println("Enter zipcode : ");
		String strr=scan();
		while(true)
		{
		result=custservice.isValidZipCode(strr);
		if(result)
		{
			customerBean.setZipcode(strr);;
			break;
		}
		else
		{
			System.err.println("enter [6] digit zipcode ");
			strr= scan();
		}
		}
		
		
		System.out.println("Enter country:");
		customerBean.setCountry(scanner.next());

		
		customerService = new CustomerServiceImpl();
		try {
			customerService.validatecustomer(customerBean);
			return customerBean;
		}
		catch (CustomerException customerException) {
			logger.error("exception occured", customerException);
			System.err.println("Invalid data:");
			System.err.println(customerException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
	
	public static String scan() {
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		return scan.nextLine();	
		}
}
