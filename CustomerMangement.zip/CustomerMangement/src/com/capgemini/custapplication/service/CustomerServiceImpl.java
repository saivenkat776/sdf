package com.capgemini.custapplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.dao.CustomerDaoImpl;
import com.capgemini.custapplication.dao.ICustomerDAO;
import com.capgemini.custapplication.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService  
{
	
	ICustomerDAO custDao;
	
	
	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addCustDetails(CustBean cust)
	 - Input Parameters	:	CustBean cust
	 - Return Type		:	String
	 - Throws			:  	CustomerException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	16/06/2019
	 - Description		:	Adding Customer Details
	 ********************************************************************************************************/
	
	public String addCustomerDetails(CustomerBean cust) throws CustomerException {
		custDao=new CustomerDaoImpl();	
		String custSeq;
		custSeq= custDao.addCustomerDetails(cust);
		return custSeq; 
	}
	
	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteAllDetails(String cust1)
	 - Input Parameters	:	String cust1
	 - Return Type		:	void
	 - Throws			:  	CustomerException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	16/06/2019
	 - Description		:	Delete Customer Details
	 ********************************************************************************************************/
	
	public void deleteCustomerDetails(int idd1) throws CustomerException
	{
		CustomerDaoImpl custDao=new CustomerDaoImpl();
		String cust1=Integer.toString(idd1);
		CustomerBean bean;
		bean=custDao.deleteCustomerDetails(cust1);
		return;
	}
	
	//------------------------ 1. Customer Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	UpdateCustDetails(nt d,String email,String name)
		 - Input Parameters	:	Custid,email,name
		 - Return Type		:	String
		 - Throws			:  	CustomerException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	16/06/2019
		 - Description		:	Updating Customer Details
		 ********************************************************************************************************/
	//update Customer details

		 public String updateCustomerDetails(CustomerBean customer) throws CustomerException {
	     custDao=new CustomerDaoImpl();	
	     String customerSeq;
	     customerSeq= custDao.updateCustomerDetails(customer);
	     return customerSeq; 
	       }

	
	//------------------------ 1. Customer Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	retriveAllDetails()
			 - Input Parameters	:	
			 - Return Type		:	List
			 - Throws			:  	CustomerException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	16/06/2019
			 - Description		:	Listing Customer Details
			 ********************************************************************************************************/
	public List<CustomerBean> retriveAll() throws CustomerException {
		 custDao=new CustomerDaoImpl();
		List<CustomerBean> custList = null;
		custList=custDao.retriveAllDetails();
		return custList;
	}
	//------------------------ 1. Customer Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	LoginAllAdmin(String email)
		 - Input Parameters	:	String 
		 - Return Type		:	String email
		 - Throws			:  	CustomerException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	16/06/2019
		 - Description		:	LoginAdmin
		 ********************************************************************************************************/
	
	public String loginadmin(String email) throws CustomerException {
		CustomerDaoImpl userDao=new CustomerDaoImpl();
		String pwd=userDao.loginadmin(email); 
		return pwd;
	}
	//------------------------ 1. Customer Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	validateId(String customerId)
			 - Input Parameters	:	String 
			 - Return Type		:	String customerId
			 - Throws			:  	CustomerException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	16/06/2019
			 - Description		:	validateId
			 ********************************************************************************************************/
	
	public boolean validateId(String customerId) throws CustomerException {
		custDao=new CustomerDaoImpl();
		boolean idStatus;
		CustomerBean bean=null;
		idStatus=custDao.validateId(customerId);
		return idStatus;
	}
	

	public void validatecustomer(CustomerBean bean) throws CustomerException
	{
		List<String> validationErrors = new ArrayList<String>();
      
		if(!(isValidEmail(bean.getEmail()))) {
			validationErrors.add("\n EMAIL SHOULD CONTAIN SPECIAL CHARACTER LIKE @ AND ENDED WITH .COM \n");
		}
	
		if(!(isValidFullName(bean.getFullname()))) {
			validationErrors.add("\n customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		if(!(isValidPassword(bean.getPassword())))
		{
			validationErrors.add("\n password can be alphabets and numeric \n");
		}
		
		if(!(isValidConfirmPassword(bean.getConfirmpassword(),bean.getPassword())))
		{
			validationErrors.add("\n password invalid \n");
		}
		
		
		//Validating address
		if(!(isValidAddress(bean.getAddress()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhonenumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		//Validating Donation ZipCode
		if(!(isValidZipCode(bean.getZipcode()))){
			validationErrors.add("\n ZipCode should not be greater than 6 \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new CustomerException(validationErrors +"");
	}

	public boolean isValidPassword(String password) {
		if(password.length()>=6)
			return true;
		else
		return false;
	}
	
	public boolean isValidConfirmPassword(String confirmpassword,String password) {
		if(confirmpassword.equals(password))
			return true;
		else
	      	return false;
	}

	public boolean isValidEmail(String email) 
	{
		Pattern namePattern=Pattern.compile("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$");
		Matcher nameMatcher=namePattern.matcher(email);
		if(nameMatcher.matches())
		return true;
		else
			return false;
	}

	public boolean isValidFullName(String custName){
		Pattern namePattern=Pattern.compile("^[a-zA-Z]+(\\s[a-zA-Z]+)?$");
		Matcher nameMatcher=namePattern.matcher(custName);
		if( nameMatcher.matches())
			return true;
		else
			return false;
	}
	
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(CharSequence l){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(l);
		if(phoneMatcher.matches())
		return true;
		else
		return false;
		
	}
	
	public boolean isValidZipCode(String ZipCode)
	{
		Pattern zipPattern = Pattern.compile("^[1-9][0-9]{5}$");
		Matcher zipMatcher = zipPattern.matcher(ZipCode);
		
		if(zipMatcher.matches())
			return true;
		else
			return false;	
	}
	
	
	public boolean isValidateCustomerId(String CustomerId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(CustomerId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	
	/*private boolean isValidCustomerId(int customerid) {
		// TODO Auto-generated method stub
		return false;
	}*/


	
}

	
	


