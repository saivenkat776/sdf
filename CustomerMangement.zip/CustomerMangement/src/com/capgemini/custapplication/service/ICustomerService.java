package com.capgemini.custapplication.service;

import java.util.List;

import com.capgemini.custapplication.bean.CustomerBean;
import com.capgemini.custapplication.exception.CustomerException;

public interface ICustomerService {

	public String addCustomerDetails(CustomerBean cust) throws CustomerException;
	public List<CustomerBean> retriveAll()throws CustomerException;
	public String loginadmin(String email) throws CustomerException ;
	public void validatecustomer(CustomerBean bean) throws CustomerException;
	//public boolean updateCustomerDetails(int d,String email,String name) throws CustomerException;
	public void deleteCustomerDetails(int idd1) throws CustomerException;
	public boolean validateId(String customerId) throws CustomerException;
    public String updateCustomerDetails(CustomerBean customer) throws CustomerException;
}
